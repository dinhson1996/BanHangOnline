package com.vuongbachthu.shoponline.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.vuongbachthu.shoponline.R;

public class ThongTinActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thong_tin);
    }
}
